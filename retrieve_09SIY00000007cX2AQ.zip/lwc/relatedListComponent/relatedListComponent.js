import { LightningElement, api, wire, track } from 'lwc';
import getObjects from '@salesforce/apex/ObjectsController.getObjects';

const columns = [
    { label: 'Name', fieldName: 'Name'},
];

export default class anotherAttempt extends LightningElement {
    @api recordId;
    @track data;
    @track error;
    columns = columns;
    @wire(getObjects, {
        recId: '$recordId'
    })
    wiredObject({data, error}) {
        if (data) {
            this.error = undefined;
            let d = [];
            JSON.parse(data).forEach(element => {

                if (element.ObjsC__r !== undefined) {
                    d.push(element.ObjsC__r);
                }
                d.push(element);
            })
            this.data = d;
        } else if (error) {
            this.error = error;
            this.data = undefined;
        }
    }
}