import { LightningElement, api, wire, track } from 'lwc';
import getObjects from '@salesforce/apex/ObjectsControllerV1.getObjects';

const columns = [
    { label: 'Name', fieldName: 'Name'},
];

export default class rListComponent extends LightningElement {
    @api recordId;
    @track objsB;
    @track error;
    columns = columns;
    @wire(getObjects, {
        recId: '$recordId'
    })
    wiredObject({data, error}) {
        if (data) {
            this.objsB = data;
            this.error = undefined;
        } else if (error) {
            this.error = error;
            this.objsB = undefined;
        }
    }
}